var app = app || {};

(function BaseView(doc) {

	var BaseView = {

		// name of the view
		name: 'BaseView',

		// all DOM elements
		els: {
			
			// navigation elements
			nav: {
				mainNav: doc.querySelector('.nav'),
				mainLink: doc.querySelectorAll('.nav-link'),
				certain: doc.querySelector('.menu-certain'),
				menuBtn: doc.querySelector('.menu-btn')
			},

			// subnavigation elements
			subnavigation: {
				links: doc.querySelectorAll('.scroll'),
				subLinks: doc.querySelectorAll('.sub-menu-link')
			},

			//video elements
			video: {
				videoLinks: doc.querySelectorAll('.open-video'),
				closeVideoLink: '.close-video',
				videoCertain: '.video-certain',
				videoPopup: '.video-popup'
			},

			// video questions and answers
			popup: {
				popupLink: doc.querySelectorAll('.popup-link'),
				popupTemplate: '.popup-data',
				popupClose: '.close-popup',
				popupCertain: '.popup-certain',
				popupMainWrapper: '.popup-main-wrapper',
				popupVideoBtn: '.open-popup-video',
				popupvideoWrapper: '.popup-video-wrapper',
				popupvideoClose: '.close-popup-video',
				popupVideoPlaceholder: '.open-popup-video-frame'
			}
		},

		events: {
			on: function(el, eventName, handler) {
				Events.subscribe(el, eventName, handler);
			},

			off: function(el, eventName, handler) {
				Events.unsubscribe(el, eventName, handler);
			},

			notify: function(el, eventName, params) {
				Events.publish(el, eventName, params);
			}
		},

		//Contains URL data
	    urlData: {

	    	//full URL data
	    	url: function() {
				return doc.URL;
			},

			// return URL host (localhost || domain)
			host: function() {

				var host = '';

				if (window.location.host === 'localhost') {
					host = 'localhost';
				}else{
					host = window.location.host;
				}

				return host;
			},

			// return pathname from url
			pathname: function() {
				return window.location.pathname;
			},

			// return url protocol (http: || https:)
			protocol: function() {
				return window.location.protocol;
			},
	    },

		/***
	     * Add active class (IE 9 support)
	   	 * return void
	     */
		addActive: function(el, elClass) {
		    el.className += ' ' + elClass;   
		},

		/***
	     * Remove active class (IE 9 support - not support classList)
	   	 * return void
	     */
		removeActive: function(el, removeClassName) {
			var elClass = el.className;
		    while(elClass.indexOf(removeClassName) != -1) {
		        elClass = elClass.replace(removeClassName, '');
		        elClass = elClass.trim();
		    }
		    el.className = elClass;
		},

		containsActive: function(el, className) {

			var elClass = el.className.split(' '),
				contains = false;
			
			for(var i = 0; i < elClass.length; i++) {
				if (elClass[i] === className) {	
					contains = true;
				}
			}

			return contains;
		},

		capitalizeFirstLetter: function(string) {
    		return string[0].toUpperCase() + string.slice(1);
		},

		getWiewport: function() {
			return window.innerWidth;
		}

	}

	app.BaseView = BaseView;
})(document);
