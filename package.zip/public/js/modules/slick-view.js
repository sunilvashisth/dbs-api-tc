var app = app || {};

(function startSlickCarousel($, doc) {

	//extend app BaseView
	app.Slick = Object.create(app.BaseView);

	// name of the view
	app.Slick.name = 'Slick';

	/***
     * Start scroll functionality
     * returns void
     */
	app.Slick.init = function() {
		this.bindEvents();
        this.events.notify(doc, 'start:slick:controls');
	};

	//bind this
	app.Slick.init = app.Slick.init.bind(app.Slick);

	/***
     * Bind scroll events
     * returns void
     */
	app.Slick.bindEvents = function() {

		console.log('Slick events binded');
		this.slickControls = this.slickControls.bind(this);
        this.events.on(doc, 'start:slick:controls', this.slickControls);
	};

	app.Slick.teamMembers = {

        "0": [
            "Nick Carnovale",
            [
                "Global Quality & Test CoC Leader"
            ],
            "description placeholder",
            "",
            ""
        ],

        "1": [
            "Andrew Williams",
            [
                "Global Quality & Test Offering Leader"
            ],
            "description placeholder",
            "IBM Andrew Williams.mp4",
            "IBM_Andrew_Williams_th.png"
        ],

        "2": [
            "Phil Stead",
            [
                "European Quality & Test Leader"
            ],
            "description placeholder",
            "",
            ""
        ],

        "3": [
            "Manu Sivarajan",
            [
                "Quality & Test Delivery Leader"
            ],
            "description placeholder",
            "",
            ""
        ],

        "4": [
            "Shamayun Miah",
            [
                "AIC Global Offerings Leader"
            ],
            "description placeholder",
            "",
            ""
        ] 
    };

    app.Slick.changeTeamMemberName = function(slick) {

        var slideCounter = slick.currentSlide+1,
            info = document.querySelector('.meetTheTeamInfo');
        
        info.style.opacity = 0;

    };

    app.Slick.changeTeamMemberSecondName = function(slick) {
        var slideCounter = slick.currentSlide,
            self = app.Slick,
            name = document.querySelector('.meetTheTeamMembersName'),
            work = document.querySelector('.meetTheTeamMembersWork'),
            info = document.querySelector('.meetTheTeamInfo'),
            video = document.querySelector('.meetTheTeamMembersVideo .video-link');

            // mail = document.querySelector('.meetTheTeamMembersMail'),
            // role = document.querySelector('.meetTheTeamMembersRole'),
            // phone = document.querySelector('.meetTheTeamMembersPhone');

        name.innerHTML = self.teamMembers[slideCounter][0];
        work.innerHTML = '';

        for(var i = 0; i < self.teamMembers[slideCounter][1].length; i++) {
            work.innerHTML += '<p>' + self.teamMembers[slideCounter][1][i] + '</p>';
        }

        if (self.teamMembers[slideCounter][3] !== '') {
            // self.removeActive(video, 'hidden');
            video.style.opacity = 1;
            video.setAttribute('data-video', self.teamMembers[slideCounter][3]);
            video.setAttribute('data-poster', 'thumb/' + self.teamMembers[slideCounter][4]);
            
        } else {
            // self.addActive(video, 'hidden');
            video.style.opacity = 0;
        }

        // role.innerHTML = self.teamMembers[slideCounter][2];


        // phone.innerHTML = '<a class="carousel-link" href="tel:'+ self.teamMembers[slideCounter][3] +'">' + self.teamMembers[slideCounter][3] + '</a>';
        // mail.innerHTML = '<a class="carousel-link" href="mailto:' + self.teamMembers[slideCounter][4] + '">' + self.teamMembers[slideCounter][4] + '</a>';

        //change background image function, get the remainder of the slideCounter divided by 6 as this will
        //instruct us on which background to use (1 of 6 backgrounds can be used)

        // slideCounter = slideCounter % 6;

        // $('#teamFrameImage').attr('src', 'img/teamFrame'+slideCounter+'.png');
        
        info.style.opacity = 1;

    };

	/***
     * Scroll to element functionality
     * @param {Event object} e
     * returns void
     */
	app.Slick.slickControls = function() {

        $('.slick-track').slick({
            arrows: false,
            centerMode: true,
            centermargin: '80px',
            dots: false,
            focusOnSelect: true,
            slidesToShow: 3,
            autoplay: true,
            autoplaySpeed: 3500,
            onBeforeChange: this.changeTeamMemberName,
            onAfterChange: this.changeTeamMemberSecondName,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        slidesToShow: 3,
                        infinite: true
                    }
            },
                {
                    breakpoint: 1000,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        slidesToShow: 1,
                        infinite: true
                    }
            },
                {
                    breakpoint: 400,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        slidesToShow: 1,
                        infinite: true,
                        centermargin: '20px',
                    }
            }
            ],
        });
	};
	

})(jQuery, document);
// console.log(app);