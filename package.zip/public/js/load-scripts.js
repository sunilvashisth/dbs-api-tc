// function loadScripts(scripts) {

//     var pathModules = 'js/modules/',
//         pathVendor = 'js/vendor/',
//         pathMain = 'js/',
//         mainScripts = [pathVendor + "jquery-1.9.1.min.js", pathMain + "polyfill.js", pathModules + "base-view.js", pathMain + "events.js"];
//         scriptArr = [];

//     // add main scripts
//     scriptArr.push(mainScripts);

//     // add additional vendor scripts
//     if (scripts.vendors !== '' && scripts.vendors !== undefined) {
//         for(var i = 0; i < scripts.vendors.length; i++) {
//             scriptArr.push(pathVendor + scripts.vendors[i] + '.js');  
//         }
//     }

//     // add modules scripts
//     if (scripts.modules !== '' && scripts.modules !== undefined) {
//         for(var i = 0; i < scripts.modules.length; i++) {
//             scriptArr.push(pathModules + scripts.modules[i] + '.js');     
//         }
//     }

//     // add controller script
//     scriptArr.push(pathMain + "controller.js");

//     // load all scripts
//     $LAB.setOptions({AlwaysPreserveOrder:true}).script(scriptArr)
// }

var LoadAllScripts = {
    
    // all js folders paths
    path: {
        modules: 'js/modules/',
        vendor: 'js/vendor/',
        main:'js/'
    },

    // every page scripts
    mainScripts: [
        "js/vendor/jquery-1.9.1.min.js",
        "js/polyfill.js",
        "js/modules/base-view.js",
        "js/events.js",
        "js/ajax.js"
    ],

    // controller script - last file that must be load
    controller: "js/controller.js",

    // will containe all files in vendor folder
    vendorsArr: [],

    // will containe all files in modules folder
    modulesArr: [],

    // will containe all files in root js folder
    mainScriptArr: [],

    // will containe all files that must be load
    scriptArr: [],


    /***
     * Start loading files
     * @param {Object} scripts
     * @returns void
     */
    init: function(scripts) {

        var getVendorsArr = this.addVendors(scripts.vendors),
            getModulesArr = this.addModules(scripts.modules);

            // getMainScriptsArr = this.addMainScripts()

        this.addAllScripts(this.mainScripts, getVendorsArr, getModulesArr, this.controller);

        this.loadAllScripts();
    },

    /***
     * add all files scripts in one array
     * @param {Array} main
     * @param {Array} vendors
     * @param {Array} modules
     * @param {String} controller
     * @returns void
     */
    addAllScripts: function(main, vendors, modules, controller) {

        this.scriptArr.push(main, vendors, modules, controller);
    },

    /***
     * load all script files with LAB js and run controller init function
     * @returns void
     */
    loadAllScripts: function() {
        // console.log(this.scriptArr);
        $LAB
        .setOptions({AlwaysPreserveOrder:true})
        .script(this.scriptArr)
        .wait(function() {
            
            // initialize controller.js
            app.init();
        })
    },

    /***
     * add all vendor scripts in array
     * @param {Array} vendors
     * @returns {Array} with all vendor scripts
     */
    addVendors: function(vendors) {
    
        // add additional vendor scripts
        if (vendors !== '' && vendors !== undefined && vendors.length > 0) {
            for(var i = 0; i < vendors.length; i++) {
                this.vendorsArr.push(this.path.vendor + vendors[i] + '.js');  
            }
        }

        return this.vendorsArr;
    },

    /***
     * add all modules scripts in array
     * @param {Array} modules
     * @returns {Array} with all modules scripts
     */
    addModules: function(modules) {
        
        // add modules scripts
        if (modules !== '' && modules !== undefined && modules.length > 0) {
            for(var i = 0; i < modules.length; i++) {
                this.modulesArr.push(this.path.modules + modules[i] + '.js');     
            }
        }

        return this.modulesArr;
    }
}