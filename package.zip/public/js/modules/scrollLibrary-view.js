var app = app || {};

(function ScrollLibraryModule(doc, global) {
	
	// var requestAnimationFrame = global.RequestAnimationFrame() || global.mozRequestAnimationFrame() || global.msRequestAnimationFrame() || global.oRequestAnimationFrame();
	// console.log(requestAnimationFrame);
	app.ScrollLibrary = Object.create(app.BaseView);

	app.ScrollLibrary.name = "ScrollLibrary";

	/***
     * Start scroll functionality
     * returns void
     */
	app.ScrollLibrary.init = function () {
		this.cacheElements();
		this.bindEvents();
		console.log(this.viewport);
		if (app.Scroll !== undefined) {
			// app.Scroll.unbindEvents();
			console.log(app.Scroll);
		}
	};

	//bind this
	app.ScrollLibrary.init = app.ScrollLibrary.init.bind(app.ScrollLibrary);

	app.ScrollLibrary.els.section = doc.querySelectorAll('[js-animation]');
	app.ScrollLibrary.viewport = {
			windowHeight: global.innerHeight
	};
	app.ScrollLibrary.previousScroll = 0;
	app.ScrollLibrary.position = 'down';
	app.ScrollLibrary.lastIndex = 0;
	app.ScrollLibrary.counter = 1;
	app.ScrollLibrary.obj = {};

	app.ScrollLibrary.bindEvents = function () {
		console.log('ScrollLibrary binded');
		global.addEventListener('scroll', this.scrollFunc);	
	};

	app.ScrollLibrary.cacheElements = function() {

		this.viewportWidth = this.getWiewport();

		// console.log(this.viewport);
		for(var i = 0; i < this.els.section.length; i++) {

			this.obj[i] = {
				el: this.els.section[i],
				offsetTop: this.els.section[i].offsetTop,
				offsetHeight: this.els.section[i].offsetTop + this.els.section[i].offsetHeight,
				height: this.els.section[i].offsetHeight,
				animationEls: this.els.section[i].querySelectorAll('[data-type]'),
				parallax: this.els.section[i].hasAttribute('parallax')
			}
		}
		// console.log(this.obj[1].animationEls);
	};

	app.ScrollLibrary.scrollFunc = function() {
		var self = app.ScrollLibrary,
			visible = self.viewport.windowHeight / 2, //2.5,
			windowTopPosition = global.pageYOffset,
			windowBottomPosition = windowTopPosition + self.viewport.windowHeight;
		console.log(2.6);

		self.addActiveOnHeader();
		if (app.Scroll !== undefined) {
			// console.log(app.Scroll);
			app.Scroll.addActiveOnSubNavOnScroll();
		}
		//loop through animated parent elements
		for(var index in self.obj) {
			
			//get each parent element data
		    var element = self.obj[index].el,
		    	childElements = self.obj[index].animationEls
		    	parallax = self.obj[index].parallax,
		    	elementHeight = element.offsetHeight,
		    	elementTopPosition = element.offsetTop,
		    	visibleElHight = self.obj[index].height / 2,
		    	elementBottomPosition = (elementTopPosition + elementHeight);
		    	// console.log(visibleElHight);
		    // if (parallax) {
	    	// 	self.parallax(self.obj[index], windowTopPosition);
	    	// 	console.log('pppppppppppppppppppp');
	    	// }
		    //check to see if this current container is within viewport
		    if ((elementBottomPosition >= windowTopPosition + visibleElHight) && (elementTopPosition + visible <= windowBottomPosition)) {

		    	//add each parent in-view class when is in viewport
		    	element.classList.add('in-view');
				console.log(self.viewportWidth);
			    if (parallax && self.viewportWidth > 960) {
			    	// global.requestAnimationFrame(function() {
			    		self.parallax(self.obj[index], windowTopPosition);
			    	// });
		    		// self.parallax(self.obj[index], windowTopPosition);
		    	}
		    	
		    	//check for child elements if not empty run their animations
		    	if (childElements.length > 0) {
		    		self.checkChildElements(childElements);
		    	}

		    // start animation from bottom
		    } else {
		    	if (element.hasAttribute('both-side-animation')) {
		    		self.bothSideAnimation(element, childElements);
		    	}
		    }
		}
	};

	app.ScrollLibrary.checkChildElements = function(childElements) {

		//get child elements
    	if (childElements.length > 0 && childElements !== 'undefined') {

    		//loop through child elemnts to start animation
    		for(var j = 0; j < childElements.length; j++) {

    			if (childElements[j].hasAttribute('one-by-one')) {
    				this.oneByOne(childElements[j], childElements[j].getAttribute('one-by-one'));

    			} else {
    				// console.log('in else');
    				childElements[j].classList.add(childElements[j].getAttribute('data-type'));
    			}
    		}

    	}
	};

	app.ScrollLibrary.oneByOne = function(el, time) {

		var elClass = el.getAttribute('data-type');

		// console.log(el);

		var x = setTimeout(function() {
			// console.log(el);
			el.classList.add(elClass);
			// el.style.background = 'purple';
		}, 1000 * time);
	};

	app.ScrollLibrary.bothSideAnimation = function(parent, childElements) {

		parent.classList.remove('in-view');

		if (childElements.length >= 1 && childElements !== 'undefined') {
    		for(var j = 0; j < childElements.length; j++) {
    			childElements[j].classList.remove(childElements[j].getAttribute('data-type'));
    		}
    	}
	};

	app.ScrollLibrary.scrollPosition = function() {
		var self = app.ScrollLibrary,
			currentScroll = doc.body.scrollTop;

		if (currentScroll > self.previousScroll){
	   		// console.log('down');
	   		self.position = 'down';
		} else {
			// console.log('up');
			self.position = 'up';
		}

		if ((global.innerHeight + global.scrollY) >= doc.body.offsetHeight) {
			// console.log("bottom");
	   		self.position = 'bottom';
		}

		self.previousScroll = currentScroll;
	};

	app.ScrollLibrary.parallax = function(parentObj, windowTopPosition) {
		// console.log(windowTopPosition);
		// parent.style.backgroundAttachment = 'fixed';
		// console.log('paralaxxxxxxxx');
		var parent = parentObj.el,
			translateX = 0,
			translateY = 0,
			dataScroll = 1,
			dataPosition,
			currentWindowScroll = windowTopPosition - parentObj.offsetTop, 
			parentHeight = parentObj.height,
			childEls = parentObj.animationEls,
			self = app.ScrollLibrary;
			// childEls = parent.querySelectorAll('[parallax-child]');
			// console.log(parentObj.animationEls);
			// console.log(parent);
		parent.style.backgroundPosition = '0 ' + -currentWindowScroll / 2 + 'px';

		// console.log(parent.querySelectorAll('[parallax-child]'));
		// console.log(currentWindowScroll);
		if (childEls.length > 1 && windowTopPosition < (parentObj.offsetTop+parentHeight) / 1.2) {
			// console.log(currentWindowScroll + ' < ' + parentHeight / 1.2);

			for(var i = 0; i < childEls.length; i++) {

				// dataScroll = childEls[i].getAttribute('data-scroll');
				dataPosition = (childEls[i].hasAttribute('data-position')) ? JSON.parse(childEls[i].getAttribute('data-position')) : false;
				// console.log(dataPosition.x);
				// console.log(dataPosition.y);
				// console.log(dataPosition.scroll);
				// console.log(dataPosition);

				if (dataPosition) {
					if (dataPosition.x === "") {
						translateX = 0;
					} else if (dataPosition.x === 'right') {
						translateX = currentWindowScroll;
					} else {
						translateX = -currentWindowScroll;
					}

					if (dataPosition.y === "") {
						translateY = 0;
					} else if (dataPosition.y === 'down') {
						translateY = currentWindowScroll;
					} else {
						translateY = -currentWindowScroll;
					}
				}
				dataScroll = dataPosition.scroll;
				// if (parent.classList.contains('in-view')) {
				childEls[i].style.transform = 'translate(' + translateX / dataScroll + 'px, ' + translateY / dataScroll + 'px)';
				// }

			}
		} 

		// global.requestAnimationFrame(function() {
  //   		self.parallax(parentObj, windowTopPosition);
  //   	});
		// else if (childEls.length === 1 && windowTopPosition < parentHeight / 1.2) {

		// 	childEls[0].style.transform = 'translate(' + windowTopPosition + 'px, ' + windowTopPosition + 'px)';

		// }
	};

	app.ScrollLibrary.addActiveOnHeader = function() {

		var header = doc.querySelector('.header'),
			yOffset = window.pageYOffset;
			console.log(yOffset);
			var contains = this.containsActive(header, 'active');

		if (!contains && yOffset > 0) {
			this.addActive(header, 'active');
		} else if (contains && yOffset === 0) {
			this.removeActive(header, 'active');
		}
	};

})(document, window);