var app = app || {};

(function activateSlider($, doc) {

	app.Slider = Object.create(app.BaseView);

	app.Slider.name = "Slider";

	/***
     * Start scroll functionality
     * returns void
     */
	app.Slider.init = function () {
		this.bindEvents();
		this.events.notify(doc, 'activate:slider');
	};

	//bind this
	app.Slider.init = app.Slider.init.bind(app.Slider);

	app.Slider.bindEvents = function () {
		console.log('slider binded');
		this.sliderControls = this.sliderControls.bind(this);

	    this.events.on(doc, 'activate:slider', this.sliderControls);
		
	};

	app.Slider.sliderControls = function() {
		
		var slide = $('#owl-slide');
		slide.owlCarousel({
	        items : 3,
	        lazyLoad : true,
	        navigation : false,
	        autoPlay: true
	    });
	}


})(jQuery, document);