
// get url page
// document.URL.split('/').slice(-1).pop().split('.')[0];
// Carousel start

// var navLinks = document.querySelectorAll('.scroll');
// console.log(navLinks);
// for (var i = 0; i < navLinks.length; i++) {
//     navLinks[i].addEventListener('click', scrollTo);  
//     console.log(navLinks[i]); 
// }
// function scrollTo(e) {
//     e.preventDefault();
//     var elmnt = this.getAttribute("href");
//     console.log(this.getAttribute("href"));
//     $("html, body").animate({
//         scrollTop: $(elmnt).offset().top
//     }, 2000);
// }
document.querySelector('.menu-btn').addEventListener('click', function() {
    document.querySelector('nav').classList.toggle('active');
});
$(document).ready(function() {
    $("#owl-slide").owlCarousel({
        items : 3,
        lazyLoad : true,
        navigation : false,
        autoPlay: true
    });
    $("#owl-slide1").owlCarousel({
        // items : 1,
        lazyLoad : true,
        navigation : true,
        autoPlay: true,
        singleItem : true
    });
    $("#owl-slide2").owlCarousel({
        // items : 1,
        lazyLoad : true,
        navigation : true,
        autoPlay: true,
        singleItem : true
    });
});
