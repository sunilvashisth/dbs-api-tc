var app = app || {};

(function Navigation(doc) {

	app.Popup = Object.create(app.BaseView);

	app.Popup.name = "Popup";

	/***
     * Start scroll functionality
     * returns void
     */
	app.Popup.init = function () {
		this.bindEvents();
		// this.events.notify(doc, 'current:page:active:link');
	};

	//bind this
	app.Popup.init = app.Popup.init.bind(app.Popup);

	app.Popup.bindEvents = function () {

		console.log('popup binded');

		for(var i = 0; i < this.els.popup.popupLink.length; i++) {
			this.events.on(this.els.popup.popupLink[i], 'click', this.createVideoPopup);
		}
		
	};

	app.Popup.createVideoPopup = function(e) {

		e.preventDefault();

		var self = app.Popup,
			checkForPopup = doc.querySelector(self.els.popup.popupMainWrapper),
			wholeTemplate = this.querySelector(self.els.popup.popupTemplate),
			cln = wholeTemplate.cloneNode(true);

		//check if popup exist. If not create new popup
		if (checkForPopup === null) {

			var popup = doc.createElement('div'),
				popupCertain = doc.createElement('div');
			popup.className = "popup-main-wrapper";
			popupCertain.className = "popup-certain";

			// popup.innerHTML = cln;
			popup.appendChild(cln);
			
			doc.body.appendChild(popupCertain);
			doc.body.appendChild(popup);

			var closePopupLink = doc.querySelector(self.els.popup.popupMainWrapper + ' ' + self.els.popup.popupClose),
				popupVideoButton = doc.querySelector(self.els.popup.popupMainWrapper + ' ' + self.els.popup.popupVideoBtn),
				popupCertain = doc.querySelector('.popup-certain');

			// bind close btn event and popup video btn event
			self.closePopup = self.closePopup.bind(self);
			self.events.on(closePopupLink, 'click', self.closePopup);
			self.events.on(popupCertain, 'click', self.closePopup);

			if (popupVideoButton) {
				self.events.on(popupVideoButton, 'click', self.openVideoTab);
			}

		}else{
			console.log('popup exist');
		}
	};

	app.Popup.openVideoTab = function() {

		var self = app.Popup,
			showVideoTab = doc.querySelector(self.els.popup.popupMainWrapper + ' ' + self.els.popup.popupvideoWrapper),
			popupSection = doc.querySelector(self.els.popup.popupMainWrapper + ' .popup-section');
		
		//check in video tags exits and add the video
		if (showVideoTab) {
			var videoTitle = this.querySelector('.hidden-video-title').innerHTML,
				videoId = this.getAttribute('data-video'),
				videoType = this.getAttribute('data-type'),
				videoPoster = this.getAttribute('data-poster'),
				videoTemplate = self.popupMarkup(videoTitle, videoId, videoType, videoPoster),
				videoPlaceholder = doc.querySelector(self.els.popup.popupMainWrapper + ' .open-popup-video-frame');
			
			self.addActive(popupSection, 'active');
			self.addActive(showVideoTab, 'active');
			videoPlaceholder.innerHTML = videoTemplate;

			var videoCloseBtn = showVideoTab.querySelector(self.els.popup.popupVideoPlaceholder + ' ' + self.els.popup.popupvideoClose);
			self.closeVideoTab = self.closeVideoTab.bind(self);
			self.events.on(videoCloseBtn, 'click', self.closeVideoTab);
		}






	};

	app.Popup.popupMarkup = function(videoTitle, videoId, videoType, videoPoster) {

		//popup template
		var wholeTemplate = '',
			popupTemplate = '',
			popupTemplateYouTube = ['<span class="close-popup-video">Close Video</span>',
									'<iframe src="https://www.youtube.com/embed/' + videoId +'" frameborder="0" allowfullscreen></iframe>',
									'<h2 class="popup-inner-video-title">' + videoTitle + '</h2>'],
			popupTemplateHTML = ['<span class="close-popup-video">Close Video</span>',
								'<video controls poster="img/' + videoPoster +'">',
                                    '<source src="video/' + videoId + '" type="video/mp4">',
                                '</video>',
                                '<h2 class="popup-inner-video-title">' + videoTitle + '</h2>'];


		if (videoType === 'html') {
			popupTemplate = popupTemplateHTML;
		}else {
			popupTemplate = popupTemplateYouTube;
		}

		for(var i = 0; i < popupTemplate.length; i++) {
			wholeTemplate += popupTemplate[i];				
		}

		return wholeTemplate;		
	};

	app.Popup.closeVideoTab = function() {
		var videoWrapper = doc.querySelector(this.els.popup.popupMainWrapper + ' ' + this.els.popup.popupvideoWrapper),
			videoPlaceholder = doc.querySelector(this.els.popup.popupMainWrapper + ' ' + this.els.popup.popupVideoPlaceholder),
			closeVideoLink = doc.querySelector(this.els.popup.popupVideoPlaceholder + ' ' + this.els.popup.popupvideoClose),
			popupSection = doc.querySelector(this.els.popup.popupMainWrapper + ' .popup-section');
		
		videoPlaceholder.innerHTML = '';

		this.removeActive(videoWrapper, 'active');
		this.removeActive(popupSection, 'active');

		this.events.off(closeVideoLink, 'click', this.closeVideoTab);
	};

	app.Popup.closePopup = function() {

		var popupTemplate = doc.querySelector(this.els.popup.popupMainWrapper),
			popupCertain = doc.querySelector(this.els.popup.popupCertain),
			closePopupLink = doc.querySelector(this.els.popup.popupClose),
			popupCertain = doc.querySelector('.popup-certain');

		//unbind close btn event
		this.events.off(closePopupLink, 'click', this.closePopup);
		this.events.off(popupCertain, 'click', this.closePopup);

		//remove popup template from DOM
		doc.body.removeChild(popupCertain);
		doc.body.removeChild(popupTemplate);

	};

})(document);