var app = app || {};

(function activateResources(doc) {

	app.Resources = Object.create(app.BaseView);

	app.Resources.name = "Resources";

	/***
     * Start scroll functionality
     * returns void
     */
	app.Resources.init = function () {
		this.bindEvents();
	};

	//bind this
	app.Resources.init = app.Resources.init.bind(app.Resources);

	app.Resources.els.resources = {
		form: doc.querySelector('.resources-form')
	}

	app.Resources.bindEvents = function () {
		console.log('resources binded');
		this.getData = this.getData.bind(this);

		this.events.on(this.els.resources.form, 'submit', this.getData);
	};

	app.Resources.resoucesData = function() {
		var data = {
			d0: {
				upl: {"iv":"P6Njp4jDF3j/TTFTLiVjfg==","v":1,"iter":1000,"ks":128,"ts":64,"mode":"ccm","adata":"","cipher":"aes","salt":[1165052521, 1817279025, 1817724221],"ct":"dHm7vs7Ix98ZbxdeIPigsIYpSOI="},
				url: 'gartner' 
			},
			d1: {
				upl: {"iv":"0/5k8Ovkc3C5xalPgCgEPQ==","v":1,"iter":1000,"ks":128,"ts":64,"mode":"ccm","adata":"","cipher":"aes","salt":[1313492570, 1363958093, 1647333693],"ct":"Rzcgbre9+/oQShqv7EfPhrx3HdzaCQ=="},
				url: 'forrester' 
			},
			d2: {
				upl: {"iv":"cK4r23J/V86ulikObNjScw==","v":1,"iter":1000,"ks":128,"ts":64,"mode":"ccm","adata":"","cipher":"aes","salt":[1281641035, 929449817, 1667779901],"ct":"fyjHYQmw1YzBLbcr/Q5jHdU="},
				url: 'idc' 
			},
			d3: {
				upl: {"iv":"t/vN/wqscttt6jW5LEKwUQ==","v":1,"iter":1000,"ks":128,"ts":64,"mode":"ccm","adata":"","cipher":"aes","salt":[1702519126, 1867399986, 1900558397],"ct":"VHNvkSp2IqzEVirCGXlf/g=="},
				url: 'hfs' 
			},
			d4: {
				upl: {"iv":"ecFvEaVG7K7ANFPe0YWENw==","v":1,"iter":1000,"ks":128,"ts":64,"mode":"ccm","adata":"","cipher":"aes","salt":[913457476, 1967407736, 1264798013],"ct":"fstQn7d7665QgjbU1/e5HEKtOOQ="},
				url: 'everest' 
			},
			d5: {
				upl: {"iv":"j7nQukMrIIoV8N8/4MirTQ==","v":1,"iter":1000,"ks":128,"ts":64,"mode":"ccm","adata":"","cipher":"aes","salt":[1718965840, 1749842037, 1145993021],"ct":"4W40CzRVGuJX65h4wnnSUcbSgodYqTU="},
				url: 'nelsonhall' 
			}
		}

        return data;
	};

	app.Resources.x = function(a) {
		return sjcl.codec.utf8String.fromBits(a)
	};

	app.Resources.d = function(check) {

		var s = this.x(check.salt);
		check.salt = s;
		var z = sjcl.decrypt("kdjaskljfklsdjfsajdkasjdklas", JSON.stringify(check));
		return z;
	};

	app.Resources.getData = function(e) {
		e.preventDefault();
		
		var un = doc.querySelector('#username'),
			ps = doc.querySelector('#password'),
			ep = doc.querySelector('.error-placeholder');
			data = this.resoucesData(),
			o = false;

		for(var d in data) {

			if ((data[d].url + '_user') === un.value && this.d(data[d].upl) === ps.value) {

				console.log('login');
				o = true;

				localStorage.setItem("check", sjcl.encrypt(this.k, data[d].url));

				window.location = data[d].url + '.html';

				break;
			}

		}
		if (!o) {

			console.log('fail');

			ep.innerHTML = '<p class="form-error">Wrong username or password</p>';
			this.addActive(un, 'error');
			this.addActive(ps, 'error');
		}
	}


})(document);