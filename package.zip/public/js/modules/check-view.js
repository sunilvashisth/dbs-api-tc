var app = app || {};

(function activateSlider(doc) {

	app.Check = Object.create(app.BaseView);

	app.Check.name = "Check";

	/***
     * Start scroll functionality
     * returns void
     */
	app.Check.init = function () {
		this.bindEvents();
		this.events.notify(doc, 'activate:check');
	};

	//bind this
	app.Check.init = app.Check.init.bind(app.Check);

	app.Check.bindEvents = function () {

		console.log('Check binded');
		this.checkControls = this.checkControls.bind(this);
		this.checkData = this.checkData.bind(this);

	    this.events.on(doc, 'activate:check', this.checkControls);
	    this.events.on(doc.querySelector('.logout'), 'click', this.checkData);
		
	};

	app.Check.checkControls = function() {
		if ((localStorage.getItem("check") && sjcl.decrypt(this.k, localStorage.getItem("check")) !== this.urlData.pathname().split('/').slice(-1).pop().split('.').slice(0, 1).pop()) || localStorage.getItem("check") === null) {window.location = 'resources.html';} else {doc.body.style.display = "block";}
	};

	app.Check.checkData = function(e) {
		e.preventDefault();
		localStorage.removeItem("check");
		window.location = 'resources.html';
	}


})(document);