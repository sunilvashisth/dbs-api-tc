var app = app || {};

(function Navigation(doc) {

	app.Video = Object.create(app.BaseView);

	app.Video.name = "Video";

	/***
     * Start scroll functionality
     * returns void
     */
	app.Video.init = function () {
		this.bindEvents();
		// this.events.notify(doc, 'current:page:active:link');
	};

	//bind this
	app.Video.init = app.Video.init.bind(app.Video);

	app.Video.bindEvents = function () {
		console.log('video binded');

		for(var i = 0; i < this.els.video.videoLinks.length; i++) {
			this.events.on(this.els.video.videoLinks[i], 'click', this.createVideoPopup);
		}
		
	};

	app.Video.createVideoPopup = function(e) {

		e.preventDefault();

		var self = app.Video,
			checkForPopup = doc.querySelector('.video-popup'),
			videoTitle = this.querySelector('.hidden-video-title').innerHTML,
			videoId = this.getAttribute("data-video"),
			videoType = this.getAttribute('data-type'),
			videoPoster = this.getAttribute('data-poster'),
			wholeTemplate = app.Video.popupMarkup(videoTitle, videoId, videoType, videoPoster);
			console.log(videoPoster);
			
		//check if popup exist. If not create new popup
		if (checkForPopup === null) {

			var popup = doc.createElement('div'),
				videoCertain = doc.createElement('div');
			popup.className = "video-popup";
			videoCertain.className = "video-certain";

			popup.innerHTML = wholeTemplate;
			doc.body.appendChild(videoCertain);
			doc.body.appendChild(popup);

			//bind close btn event
			self.closePopup = self.closePopup.bind(self);
			self.events.on(doc.querySelector(self.els.video.closeVideoLink), 'click', self.closePopup);

		}else{
			console.log('popup exist');
		}
	};

	app.Video.popupMarkup = function(videoTitle, videoId, videoType, videoPoster) {
		//popup template
		var wholeTemplate = '',
			popupTemplate = '',
			popupTemplateYouTube = ['<div class="video-img-wrapper">', 
								'<iframe src="https://www.youtube.com/embed/' + videoId +'" frameborder="0" allowfullscreen></iframe>',
							'</div>',
							'<h1 class="video-title">' + videoTitle + '</h1>',
							'<div class="btn-video-wrapper">',
								'<a href="javascript:;" class="close-video">close</a>',
							'</div>'],
			popupTemplateHTML = ['<div class="video-img-wrapper">',
                                '<video controls poster="img/' + videoPoster +'">',
                                    '<source src="video/' + videoId + '" type="video/mp4">',
                                '</video>',
                            '</div>',
							'</div>',
							'<h1 class="video-title">' + videoTitle + '</h1>',
							'<div class="btn-video-wrapper">',
								'<a href="javascript:;" class="close-video">close</a>',
							'</div>'];


		if (videoType === 'html') {
			popupTemplate = popupTemplateHTML;
		}else {
			popupTemplate = popupTemplateYouTube;
		}

		for(var i = 0; i < popupTemplate.length; i++) {
			wholeTemplate += popupTemplate[i];				
		}

		return wholeTemplate;		
	}

	app.Video.closePopup = function() {

		var popupTemplate = doc.querySelector(this.els.video.videoPopup),
			videoCertain = doc.querySelector(this.els.video.videoCertain)
			closePopupLink = doc.querySelector(this.els.video.closeVideoLink);

		//unbind close btn event
		this.events.off(closePopupLink, 'click', this.closePopup);

		//remove popup template from DOM
		doc.body.removeChild(videoCertain);
		doc.body.removeChild(popupTemplate);

	};

})(document);