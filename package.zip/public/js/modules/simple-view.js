var app = app || {};

(function SimpleModule(doc) {

	app.Simple = Object.create(app.BaseView);

	app.Simple.name = "Simple";

	/***
     * Start scroll functionality
     * returns void
     */
	app.Simple.init = function () {
		this.bindEvents();
		// this.events.notify(doc, 'current:page:active:link');
	};

	//bind this
	app.Simple.init = app.Simple.init.bind(app.Simple);

	app.Simple.els.simple = {
		faqModule: {
			faqLink: doc.querySelectorAll('.faq-row-header'),
		},

		micrositeBox: {
			moreLink: doc.querySelectorAll('.microsite-box-more')
		},
		pricingInfoBoxBtn: {
			btn: doc.querySelectorAll('.info-box-btn'),

		}
	};

	app.Simple.bindEvents = function () {

		console.log('simple binded');
		console.log(this.els.simple.pricingInfoBoxBtn.btn);

		if (this.els.simple.micrositeBox.moreLink.length > 0) {

			for(var i = 0; i < this.els.simple.micrositeBox.moreLink.length; i++) {

				this.events.on(this.els.simple.micrositeBox.moreLink[i], 'click', this.openMicrositeBoxPopup);
			}
		}

		if (this.els.simple.faqModule.faqLink.length > 0) {

			for(var i = 0; i < this.els.simple.faqModule.faqLink.length; i++) {

				this.events.on(this.els.simple.faqModule.faqLink[i], 'click', this.toggleFaqModule);
			}
		}

		if (this.els.simple.pricingInfoBoxBtn.btn.length > 0) {

			for(var i = 0; i < this.els.simple.pricingInfoBoxBtn.btn.length; i++) {
				console.log('in loop');
				this.events.on(this.els.simple.pricingInfoBoxBtn.btn[i], 'click', this.togglePricingInfoBox);
			}
		}
		
	};

	app.Simple.openMicrositeBoxPopup = function() {

		var self = app.Simple,
			mainParent = this.parentNode.parentNode,
			boxPopup = mainParent.querySelector('.microsite-box-popup'),
			backBtn = mainParent.querySelector('.microsite-box-popup-back-btn');

			self.events.on(backBtn, 'click', self.closeMicrositeBoxPopup);

		self.addActive(mainParent, 'active');
		self.addActive(boxPopup, 'active');
	};

	app.Simple.closeMicrositeBoxPopup = function() {

		var self = app.Simple,
			popup = this.parentNode.parentNode,
			mainParent = popup.parentNode;
			
		self.removeActive(popup, 'active');
		self.removeActive(mainParent, 'active');
		self.events.off(this, 'click', self.closeMicrositeBoxPopup);

	};

	app.Simple.toggleFaqModule = function() {

		var self = app.Simple,
			parent = $(this).parent();

			$(this).siblings('.faq-content-wrapper').slideToggle(300);
			parent.toggleClass('active');
			console.log($(this).siblings('.faq-content-wrapper').height());
	}

	app.Simple.togglePricingInfoBox = function() {
		console.log(this);
		var self = app.Simple,
			infoBox = $('.pricing-info-box', $(this));

			// infoBox.css('top', $(this).height());
			// infoBox.addClass('active');
			infoBox.slideToggle(300);

	}

})(document);