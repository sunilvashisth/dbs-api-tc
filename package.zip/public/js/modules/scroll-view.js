var app = app || {};

(function startScrollAnimation($, doc) {

	//extend app BaseView
	app.Scroll = Object.create(app.BaseView);

	// name of the view
	app.Scroll.name = 'Scroll';

	/***
     * Start scroll functionality
     * returns void
     */
	app.Scroll.init = function() {
		this.bindEvents();
	};

	//bind this
	app.Scroll.init = app.Scroll.init.bind(app.Scroll);
	
	/***
     * Bind scroll events
     * returns void
     */
	app.Scroll.bindEvents = function() {

		console.log('Scroll events binded');

		// bind submenu links for scroll functionality
		for (var i = 0; i < this.els.subnavigation.links.length; i++) {

		    this.events.on(this.els.subnavigation.links[i], 'click', this.startScroll);
			console.log('events binded scroll subnav links');
		}

		this.addActiveOnSubNavOnScroll = this.addActiveOnSubNavOnScroll.bind(this);
		this.events.on(doc, 'scroll', this.addActiveOnSubNavOnScroll);
	};

	/***
     * Scroll to element functionality
     * @param {Event object} e
     * returns void
     */
	app.Scroll.startScroll = function(e) {

	    e.preventDefault();

	    var subLink = this.getAttribute('href'),
	    	self = app.BaseView;


	    for (var i = 0; i < self.els.subnavigation.links.length; i++) {

		    self.removeActive(self.els.subnavigation.links[i], 'active');
		}

	    self.addActive(this, 'active');

	    $("html, body").animate({
	        scrollTop: $(subLink).offset().top - 90
	    }, 1500, 'swing');
	};

	/***
     * add active to sub menu links on scroll
     * @param {Event object} e
     * returns void
     */
	app.Scroll.addActiveOnSubNavOnScroll = function() {

		var links = this.els.subnavigation.subLinks;

		for (var i = 0; i < links.length; i++) {

			var	linkHref = links[i].getAttribute('href'),
				sectionOffsetTop = doc.querySelector(linkHref).offsetTop,
				firstSection = doc.querySelector(links[0].getAttribute('href')).offsetTop,
				yOffset = window.pageYOffset + 150;

			if (yOffset > sectionOffsetTop) {

				if (i >= 1 && i <= links.length) {

					this.removeActive(links[i-1], 'active');
					this.addActive(links[i], 'active');

				} else {

					for (var j = 0; j < links.length; j++) {
					    this.removeActive(links[j], 'active');
					}

					this.addActive(links[i], 'active');
				}

			} else if (yOffset < firstSection) {

				this.removeActive(links[0], 'active');
			}
		}
	};

})(jQuery, document);
// console.log(app);