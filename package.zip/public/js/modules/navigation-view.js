var app = app || {};

(function NavigationModule(doc) {

	app.Navigation = Object.create(app.BaseView);

	app.Navigation.name = "Navigation";

	/***
     * Start scroll functionality
     * returns void
     */
	app.Navigation.init = function () {
		this.bindEvents();
		this.events.notify(doc, 'current:page:active:link');
		this.events.notify(doc, 'check:l');
	};

	//bind this
	app.Navigation.init = app.Navigation.init.bind(app.Navigation);

	app.Navigation.bindEvents = function () {
		console.log('nav binded');

		this.getCurrentPage = this.getCurrentPage.bind(this);
		this.showNav = this.showNav.bind(this);
		this.hideNav = this.hideNav.bind(this);
		this.checks = this.checks.bind(this);

		this.events.on(this.els.nav.menuBtn, 'click', this.showNav);
		this.events.on(this.els.nav.certain, 'click', this.hideNav);
	    this.events.on(doc, 'current:page:active:link', this.getCurrentPage);
	    this.events.on(doc, 'check:l', this.checks);
		
	};

	app.Navigation.getCurrentPage = function() {

		var url = this.urlData.url(),
			host = this.urlData.host(),
			pathName = this.urlData.pathname(),
			protocol = this.urlData.protocol(),

			checkHostname = (host === 'localhost') ? 'http://localhost/ibm/': protocol + '//' + pathName + '/';
			currentPage = (url.replace(checkHostname, '') === '') ? 'index.html': url;
			
		for (var i = 0; i < this.els.nav.mainLink.length; i++) {
			
			if (currentPage.indexOf(this.els.nav.mainLink[i].getAttribute('href')) > -1) {
				this.addActive(this.els.nav.mainLink[i], 'active');
			} else {
				this.removeActive(this.els.nav.mainLink[i], 'active');
			}
		}
	};

	app.Navigation.checks = function() {
		if (localStorage.getItem('check') !== null && typeof sjcl === "undefined") {
			localStorage.removeItem('check');
		}
	};

	app.Navigation.showNav = function() {
		// this.els.nav.mainNav.classList.add('active');
		// this.els.nav.certain.classList.add('active');
		this.addActive(this.els.nav.mainNav, 'active');
		this.addActive(this.els.nav.certain, 'active');
	};

	app.Navigation.hideNav = function() {
		this.removeActive(this.els.nav.mainNav, 'active');
		this.removeActive(this.els.nav.certain, 'active');
	};


})(document);