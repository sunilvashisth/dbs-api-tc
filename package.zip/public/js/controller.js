var app = app || {};

(function StartApp(doc) {

		/***
	     * Start app
	     * returns void
	     */
		app.init = function() {

			var loadedFiles = this.getFiles();

			// console.log(loadedFiles);

			this.bindEvents(loadedFiles);

			// this.events.notify('start:scroll');
			// this.events.notify('start:navigation');
			// this.events.notify('start:slider');
			// this.events.notify('start:video');

			for(var index in loadedFiles) {
				this.events.notify(loadedFiles[index].event);
			}
		};

		// TO DO load files with more than one word(video-question-view.js)
		app.getFiles = function() {

			var scripts = doc.querySelectorAll('script');
			var views = {};

			for(var i = 0; i < scripts.length; i++) {


				// TO DO: refactor base-view name
				if (scripts[i].src.split('/').pop().indexOf('-view.js') !== -1 && scripts[i].src.split('/').pop() !== 'base-view.js') {

					views[scripts[i].src.split('/').pop().replace('-view.js', '')] = {

						file: scripts[i].src.split('/').pop(),
						event: 'start:' + scripts[i].src.split('/').pop().replace('-view.js', ''),
						callback: app.BaseView.capitalizeFirstLetter(scripts[i].src.split('/').pop().replace('-view.js', ''))
					}
				}
				
				// console.log(scripts[i].src.split('/').pop());
				// console.log(scripts[i].src);
			}

			return views;
		}

		/***
	     * Bind events
	     * returns void
	     */
		app.bindEvents = function(loadedFiles) {
			
			// this.events.listen('start:scroll', this.Scroll.init);
			// this.events.listen('start:navigation', this.Nav.init);
			// this.events.listen('start:slider', this.Slider.init);
			// this.events.listen('start:video', this.Video.init);
			var callback = null;
			for(var index in loadedFiles) {
				callback = loadedFiles[index].callback;
				this.events.listen(loadedFiles[index].event, this[callback].init);
			}
		};

		// subscribe, publish and destroy events
		app.events = {
			// subscribe event
			listen: function(eventName, handler) {
				Events.subscribe(doc, eventName, handler);
			},

			// publish event
			notify: function(eventName) {
				Events.publish(doc, eventName);
			},

			// destroy event
			destroy: function(eventName, handler) {
				Events.destroy(doc, eventName, handler);
			}
		};

	// console.log(app);

	// start whole app
	// app.init();

})(document);
